function cRoom()
{
var hostel = document.getElementByTagName('hostel').value
 alert("hostel"+hostel)
}