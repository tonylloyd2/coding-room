from django.contrib import admin
from .models import Booking

admin.site.register(Booking)
