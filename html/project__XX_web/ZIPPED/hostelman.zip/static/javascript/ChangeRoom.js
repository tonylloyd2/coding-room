function changeroom()
{
var hostel = document.getElementById("hostel").value;
 alert("hostel"+hostel)
}