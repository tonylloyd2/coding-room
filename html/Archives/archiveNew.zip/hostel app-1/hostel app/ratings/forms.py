from django import forms 
from hostel.models import Hostel
from .models import Rating

class EmployeeForm(forms.ModelForm): 
    class Meta: 
        model = Hostel 
        fields = ['Hostel_name', 'image'] 