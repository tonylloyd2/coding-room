from django.db import models

# Create your models here.
class Payment(models.Model):
    receipt_number = models.CharField(max_length=20)
    date_paid = models.DateField()