import imp
from operator import imod
from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from hostelbookingapp.settings import MEDIA_ROOT,MEDIA_URL


urlpatterns = [
    path('admin/', admin.site.urls),
    path('base-auth/', include('rest_framework.urls')),
    path('', include('base.urls')),
    path('booking/', include('booking.urls')),
    path('hostel/', include('hostel.urls')),
    path('payment/', include('payment.urls')),
    path('ratings/' ,include('ratings.urls')),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT )
