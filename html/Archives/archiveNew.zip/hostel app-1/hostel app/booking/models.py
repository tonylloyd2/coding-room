from django.db import models

# Create your models here.
class Booking(models.Model):
    BookingID = models.IntegerField()
    HostelID = models.CharField(max_length=128)
    StudentID = models.CharField(max_length=128)
    BookingDate = models.DateField()
