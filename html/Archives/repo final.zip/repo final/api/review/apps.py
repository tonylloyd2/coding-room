from django.apps import AppConfig


class ReviewConfig(AppConfig):
    name = 'review'
